import org.junit.Test;


public class CTest {
    @Test
    public void test() {
        AbstractFactory userFactory = new UserFactory();
        User serviceOwner = userFactory.createUser(new ServiceOwner());
        User renter = userFactory.createUser(new Renter());

        AbstractFactory serviceFactory = new ServiceFactory();
        Service sportField = serviceFactory.createService(new SportField());
        Service gamingCenter = serviceFactory.createService(new GamingCenter());

    }
}
