import java.util.ArrayList;
import java.util.List;

public class Renter extends User{
    private List<Service> wishList = new ArrayList<>();

    public void addToWishList(Service service) {
        wishList.add(service);
    }

    public void bookService(int serviceID) {}

    public void viewBookings() {}

    public void editBookedService(int serviceID) {}

    public void cancelBookedService(int serviceID) {}

    public void searchServices() {}

}
