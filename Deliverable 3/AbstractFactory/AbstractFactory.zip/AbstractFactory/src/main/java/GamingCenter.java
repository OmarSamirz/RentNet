public class GamingCenter extends Service{
    private String consoles;
    private int numberOfRooms;
    private boolean airConditioning;
    private boolean soundSystem;

    public String getConsoles() {
        return consoles;
    }

    public void setConsoles(String consoles) {
        this.consoles = consoles;
    }

    public int getNumberOfRooms() {
        return numberOfRooms;
    }

    public void setNumberOfRooms(int numberOfRooms) {
        this.numberOfRooms = numberOfRooms;
    }

    public boolean isAirConditioning() {
        return airConditioning;
    }

    public void setAirConditioning(boolean airConditioning) {
        this.airConditioning = airConditioning;
    }

    public boolean isSoundSystem() {
        return soundSystem;
    }

    public void setSoundSystem(boolean soundSystem) {
        this.soundSystem = soundSystem;
    }

}
