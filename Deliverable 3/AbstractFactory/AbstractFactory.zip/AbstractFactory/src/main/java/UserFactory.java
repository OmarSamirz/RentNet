public class UserFactory extends AbstractFactory {
    @Override
    public User createUser(User userType) {
        return userType;
    }
}