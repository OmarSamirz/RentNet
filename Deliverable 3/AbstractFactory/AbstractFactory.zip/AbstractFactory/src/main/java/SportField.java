public class SportField extends Service{
    private String type;
    private int numberOfPlayers;
    private float length;
    private float width;
    private String equipment;
    private boolean changingRoom;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getNumberOfPlayers() {
        return numberOfPlayers;
    }

    public void setNumberOfPlayers(int numberOfPlayers) {
        this.numberOfPlayers = numberOfPlayers;
    }

    public float getLength() {
        return length;
    }

    public void setLength(float length) {
        this.length = length;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public String getEquipment() {
        return equipment;
    }

    public void setEquipment(String equipment) {
        this.equipment = equipment;
    }

    public boolean isChangingRoom() {
        return changingRoom;
    }

    public void setChangingRoom(boolean changingRoom) {
        this.changingRoom = changingRoom;
    }

}

