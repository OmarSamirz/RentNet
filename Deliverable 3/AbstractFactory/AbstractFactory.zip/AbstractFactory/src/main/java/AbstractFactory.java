public abstract class AbstractFactory {
    User createUser(User userType) {
        return null;
    }
    Service createService(Service serviceType) {
        return null;
    }
}