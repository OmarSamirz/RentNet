import java.time.LocalDateTime;

public abstract class Service {
    private int serviceID;
    private int serviceOwnerID;
    private String category;
    private String name;
    private String description;
    private String address;
    private float price;
    private float avgRating;
    private boolean wifi;
    private boolean bathroom;
    private boolean parking;
    private LocalDateTime availableTimes;

    public int getServiceID() {
        return serviceID;
    }

    public void setServiceID(int serviceID) {
        this.serviceID = serviceID;
    }

    public int getServiceOwnerID() {
        return serviceOwnerID;
    }

    public void setServiceOwnerID(int serviceOwnerID) {
        this.serviceOwnerID = serviceOwnerID;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public float getAvgRating() {
        return avgRating;
    }

    public void setAvgRating(float avgRating) {
        this.avgRating = avgRating;
    }

    public boolean isWifi() {
        return wifi;
    }

    public void setWifi(boolean wifi) {
        this.wifi = wifi;
    }

    public boolean isBathroom() {
        return bathroom;
    }

    public void setBathroom(boolean bathroom) {
        this.bathroom = bathroom;
    }

    public boolean isParking() {
        return parking;
    }

    public void setParking(boolean parking) {
        this.parking = parking;
    }

    public LocalDateTime getAvailableTimes() {
        return availableTimes;
    }

    public void setAvailableTimes(LocalDateTime availableTimes) {
        this.availableTimes = availableTimes;
    }
}
