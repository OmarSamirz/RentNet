import java.util.ArrayList;
import java.util.List;

public class ServiceOwner extends User{
    private List<Service> providedServices = new ArrayList<>();

    public void addService(Service service) {
        providedServices.add(service);
    }

    public void deleteService(int serviceID) {}

    public void checkServiceDetails(int serviceID) {}

    public void updateService(int serviceID) {}

    public void acceptRentingRequest() {}

    public void cancelRentingRequest() {}

    public void viewReservations() {}

}

