public class ServiceFactory extends AbstractFactory {

    @Override
    public Service createService(Service serviceType) {
        return serviceType;
    }
}